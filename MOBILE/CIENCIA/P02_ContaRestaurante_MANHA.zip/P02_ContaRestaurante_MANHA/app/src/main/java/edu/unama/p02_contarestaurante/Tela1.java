package edu.unama.p02_contarestaurante;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class Tela1 extends AppCompatActivity {
    // 1. Declaração de atributos dinâmicos:
    EditText editValor;
    TextView txtResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // 2. Integração entre XML e Java:
        editValor    = findViewById(R.id.edit_valor);
        txtResultado = findViewById(R.id.txt_resultado);
    } // fim do onCreate

    // 3. Criação do método que será executado quando o botão for tocado:
    public void calcResultado(View v) {
        // 4. pegar os valores do layout:
        String valorDigitado = editValor.getText().toString();
        if ( valorDigitado.trim().isEmpty() ) {
            Toast.makeText(this,
                    "Erro! Valor inválido.", Toast.LENGTH_SHORT).show();
            txtResultado.setText("-");
        } else {
            // 5. converter de String para double:
            double valor = Double.parseDouble(
                    valorDigitado.replace(",", "."));
            // 6. realizar o cálculo da conta com 10%:
            double resultado = valor * 1.1;  // (100+10)=110% = 110/100 = 1.1
            // 7. mostrar o valor calculado:
            DecimalFormat df = new DecimalFormat("#.##");
            txtResultado.setText("Conta com 10%: R$ " + df.format(resultado));
        }
    } // fim do calcResultado

} // fim da Tela1
