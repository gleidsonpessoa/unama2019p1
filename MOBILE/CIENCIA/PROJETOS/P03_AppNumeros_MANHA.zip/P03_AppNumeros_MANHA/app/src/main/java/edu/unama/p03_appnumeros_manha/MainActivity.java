package edu.unama.p03_appnumeros_manha;

import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    // 1. declaração de componentes dinâmicos e de variáveis globais:
    EditText editNumero;
    TextView txtNumeros, txtImpares, txtPares, txtSoma;
    int soma = 0, pares = 0, impares = 0;
    ArrayList<Integer> lista = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // 2. integração entre XML e Java:
        editNumero = findViewById(R.id.edit_numero);
        txtNumeros = findViewById(R.id.txt_numeros);
        txtImpares = findViewById(R.id.txt_impares);
        txtPares   = findViewById(R.id.txt_pares);
        txtSoma    = findViewById(R.id.txt_soma);
    } // fim do onCreate

    // 3. método que será chamado no toque do botão OK:
    public void cliqueOK(View v) {
        // 4. pegar valor digitado:
        String numeroDigitado = editNumero.getText().toString();
        if( numeroDigitado.isEmpty() ) {
            Toast.makeText(this, "Erro! Informe um número.",
                    Toast.LENGTH_LONG).show();
            Snackbar.make(v, "Erro! Informe um número.",
                    Snackbar.LENGTH_LONG).show();
        } else {
            // 5. converter a string para int:
            int numero = Integer.parseInt(numeroDigitado);
            // 6. inserir o número na lista:
            lista.add(numero);
            // 7. mostrar lista de números na activity:
            txtNumeros.setText(lista.toString());
            // 8. criar métodos para tratar ímpares, pares e soma:
            calcImpares(numero);
            calcPares(numero);
            calcSoma(numero);
        }
        // limpar campo de número:
        editNumero.setText( "" );
    } // fim cliqueOK

    private void calcSoma(int numero) {
        soma = soma + numero;
        txtSoma.setText( soma+"" );
    }

    private void calcPares(int numero) {
        if ( numero % 2 == 0 ) {
            pares++;
            txtPares.setText(pares+"");
        }
    }

    private void calcImpares(int numero) {
        if ( numero % 2 != 0 ) {
            impares++;
            txtImpares.setText( impares+"" );
        }
    }

} // fim da classe
