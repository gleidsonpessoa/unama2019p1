package edu.unama.p04_appgasosa_manha;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class Tela1 extends AppCompatActivity {
    // 1. declaração de componentes dinâmicos:
    EditText campoModelo, campoDistancia, campoPotencia, campoValor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela1);
        // 2. integração entre XML e Java:
        campoModelo    = findViewById(R.id.edit_modelo);
        campoDistancia = findViewById(R.id.edit_distancia);
        campoPotencia  = findViewById(R.id.edit_potencia);
        campoValor     = findViewById(R.id.edit_valor);
    } // fim do onCreate

    // 3. método disparado pelo botão:
    public void calcular(View v) {
        // 4. pegar valores informados na tela:
        String modeloDig = campoModelo.getText().toString();
        double distanciaDig = Double.parseDouble(
                campoDistancia.getText().toString() );
        double potenciaDig  = Double.parseDouble(
                campoPotencia.getText().toString() );
        double valorDig  = Double.parseDouble(
                campoValor.getText().toString() );
        // 5. fazer o cálculo:
        double valorTotal = calcularValorTotal(potenciaDig,
                valorDig, distanciaDig);
        // 6. enviar os valores para a Tela2:
        Intent tela1 = new Intent(this, Tela2.class);
        tela1.putExtra("modelo", modeloDig);
        tela1.putExtra("distancia", distanciaDig);
        tela1.putExtra("potencia", potenciaDig);
        tela1.putExtra("valor_litro", valorDig);
        tela1.putExtra("valor_total", valorTotal);
        startActivity( tela1 );
    } // fim do calcular

    private double calcularValorTotal(double potencia, double valor, double distancia) {
        double valorTotal = 0.0;
        if ( potencia <= 1.0 ) {
            valorTotal = valor * distancia / 13.0;
        } else if ( potencia > 1.0 && potencia <= 1.4 ) {
            valorTotal = valor * distancia / 11.0;
        } else if ( potencia > 1.4 && potencia <= 1.9 ) {
            valorTotal = valor * distancia / 9.5;
        } else {
            valorTotal = valor * distancia / 7.75;
        }
        return  valorTotal;
    } // fim do calcularValorTotal


} // fim da classe
