package edu.unama.p04_appgasosa_manha;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.text.DecimalFormat;

public class Tela2 extends AppCompatActivity {
    // 1. Declaração de componente dinâmico:
    TextView txtResultado;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela2);
        // 2. Integração entre XML e Java:
        txtResultado = findViewById(R.id.txt_resultado);
        // 3. pegar a Intent passada para a Tela2:
        Intent tela2 = getIntent();
        // 4. pegar os valores passados pela Tela1:
        String modelo = tela2.getStringExtra("modelo");
        double distancia = tela2.getDoubleExtra("distancia",0.0);
        double potencia  = tela2.getDoubleExtra("potencia",0.0);
        double valorLitro = tela2.getDoubleExtra("valor_litro", 0.0);
        double total = tela2.getDoubleExtra("valor_total",0.0);
        // 5. mostrar o resultado no TextView resultado
        DecimalFormat df = new DecimalFormat("#.00");
        txtResultado.setText( modelo + " " + potencia + " gasta R$ " +
                df.format(total) + " para percorrer " + distancia +
                " km com gasolina a R$ " + valorLitro + " por litro");
    } // fim do onCreate

    public void compartilhar( View v ) {
        String resultado = txtResultado.getText().toString();
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_SUBJECT, "AppGasosa");
        i.putExtra(Intent.EXTRA_TEXT, resultado);
        startActivity( Intent.createChooser(i, "Compartilhar...") );
    } // fim do compartilhar

} // fim da Tela2
