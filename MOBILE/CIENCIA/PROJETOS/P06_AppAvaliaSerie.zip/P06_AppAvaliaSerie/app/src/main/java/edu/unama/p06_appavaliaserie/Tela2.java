package edu.unama.p06_appavaliaserie;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class Tela2 extends AppCompatActivity {
    // 1. declarar componentes dinâmicos:
    TextView txtTitulo, txtGenero, txtAtivo, txtAvaliacao;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela2);
        // 2. integração entre XML e JAVA:
        txtTitulo = findViewById(R.id.tela2_titulo);
        txtGenero = findViewById(R.id.tela2_genero);
        txtAtivo  = findViewById(R.id.tela2_ativa);
        txtAvaliacao = findViewById(R.id.tela_avaliacao);
        // 3. pegar e acessar o conteúdo da Intent:
        Intent i = getIntent();
        String titulo = i.getStringExtra("titulo");
        String genero = i.getStringExtra("genero");
        String ativo  = i.getStringExtra("ativo");
        double avaliacao = i.getDoubleExtra("avaliacao",
                0.0);
        // 4. setar valores da Intent nos campos dinâmicos:
        txtTitulo.setText( titulo );
        txtGenero.setText( genero );
        txtAtivo.setText( ativo );
        txtAvaliacao.setText( String.valueOf( avaliacao ) );
    } // fim do onCreate

    // 5. associar menu da tela2:
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate( R.menu.menu_tela2, menu );
        return true;
    } // fim do onCreateOptionsMenu

    // 6. clique no menu da tela2:
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if ( id == R.id.item_compartilhar ) {
            Intent i = new Intent( Intent.ACTION_SEND );
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_SUBJECT, "App Avalia Série");
            i.putExtra(Intent.EXTRA_TEXT, "A série " +
                    txtTitulo.getText() + ", gênero " + txtGenero.getText()
                    + ", está ativa? " + txtAtivo.getText() + ". Nota: "
                    + txtAvaliacao.getText() );
            startActivity( Intent.createChooser( i , "Compartilhar") );
        } // fim do if
        return super.onOptionsItemSelected(item);
    }
} // fim da classe
