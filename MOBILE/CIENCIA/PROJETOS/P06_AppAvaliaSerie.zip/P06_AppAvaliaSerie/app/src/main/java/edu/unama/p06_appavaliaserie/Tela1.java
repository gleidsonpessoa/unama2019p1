package edu.unama.p06_appavaliaserie;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.Switch;

public class Tela1 extends AppCompatActivity {
    // 1. declarar componentes dinâmicos:
    EditText editTitulo;
    Spinner  spinGenero;
    Switch   swAtiva;
    RatingBar rbAvaliacao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela1);
        // 2. integração entre XML e Java:
        editTitulo = findViewById(R.id.edit_titulo);
        spinGenero = findViewById(R.id.spin_genero);
        swAtiva    = findViewById(R.id.sw_ativa);
        rbAvaliacao = findViewById(R.id.rb_avaliacao);
    } // fim do onCreate

    // 3. integrar o menu1 com a Tela1:
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate( R.menu.menu_tela1, menu );
        return true;
    } // fim onCreateOptionsMenu

    // 4. clique no item de menu:
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if ( id == R.id.item_avaliar ) {
            // 5. pegar valores informados na tela:
            String titulo = editTitulo.getText().toString();
            String genero = spinGenero.getSelectedItem().toString();
            boolean ativo = swAtiva.isChecked();
            double avaliacao = rbAvaliacao.getRating();
            // 6. enviar valores para Tela2:
            Intent i = new Intent(this, Tela2.class);
            i.putExtra("titulo", titulo);
            i.putExtra("genero", genero);
            i.putExtra("ativo", ativo ? "SIM" : "NÃO");
            i.putExtra("avaliacao", avaliacao);
            startActivity( i );
        } // fim do if
        return super.onOptionsItemSelected(item);
    } // fim do método onOptionsItemSelected
} // fim da classe
