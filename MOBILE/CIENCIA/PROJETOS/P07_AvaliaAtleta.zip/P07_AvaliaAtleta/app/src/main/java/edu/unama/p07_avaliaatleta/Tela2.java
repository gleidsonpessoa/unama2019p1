package edu.unama.p07_avaliaatleta;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class Tela2 extends AppCompatActivity {
    // 1. componentes dinâmicos:
    TextView txtNome, txtModalidade, txtMaior, txtMedia, txtResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela2);
        // 2. integração entre XML e Java:
        txtNome = findViewById(R.id.tela2_nome);
        txtModalidade = findViewById(R.id.tela2_modalidade);
        txtMaior = findViewById(R.id.tela2_maior);
        txtMedia = findViewById(R.id.tela2_media);
        txtResultado = findViewById(R.id.tela2_resultado);
        // 3. pegar valores da Intent:
        Intent i = getIntent();
        String nome = i.getStringExtra("nome");
        String modalidade = i.getStringExtra("modalidade");
        String maior = i.getStringExtra("maior");
        String media = "Média geral: " + i.getDoubleExtra("media",
                0.0);
        String resultado = i.getStringExtra("resultado");
        // 4. atribuir valores nos campos da Tela2:
        txtNome.setText( nome );
        txtModalidade.setText( modalidade );
        txtMaior.setText( maior );
        txtMedia.setText( media );
        txtResultado.setText( resultado );
        if ( resultado.equals("APTO") ) {
            txtResultado.setTextColor(Color.GREEN);
        } else {
            txtResultado.setTextColor(Color.RED);
        }
    } // fim do oncreate

    // 5. inflar o menu:
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate( R.menu.menu_tela2, menu );
        return true;
    } // fim do onCreateOptionsMenu

    // 6. clique no menu
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id == R.id.item_compartilhar) {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_SUBJECT, "AvaliaAtleta");
            i.putExtra(Intent.EXTRA_TEXT, "O atleta de nome " +
                    txtNome.getText() + " é " + txtMaior.getText() +
                    ". Resultado: " + txtResultado.getText());
            startActivity( Intent.createChooser(i,"Compartilhar") );
        }
        return super.onOptionsItemSelected(item);
    } // fim do clique de menu

    public void adicionarFav(View v) {
        Toast.makeText(this,
                "Adicionando aos favoritos...",
                Toast.LENGTH_SHORT).show();
    }

} // fim da classe
