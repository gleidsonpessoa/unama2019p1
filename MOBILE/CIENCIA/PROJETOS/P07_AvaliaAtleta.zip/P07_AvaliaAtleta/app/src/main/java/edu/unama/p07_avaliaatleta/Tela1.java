package edu.unama.p07_avaliaatleta;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.Switch;

public class Tela1 extends AppCompatActivity {
    // 1. componentes dinâmicos:
    EditText editNome;
    Spinner  spinModalidade;
    Switch   swMaioridade;
    RatingBar rbBio, rbPsi, rbGen;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela1);
        // 2. integração entre XML e Java:
        editNome = findViewById(R.id.edit_nome);
        spinModalidade = findViewById(R.id.spin_modalidade);
        swMaioridade = findViewById(R.id.sw_maior);
        rbBio = findViewById(R.id.rb_bio);
        rbPsi = findViewById(R.id.rb_psi);
        rbGen = findViewById(R.id.rb_gen);
    } // fim do onCreate

    // 3. inflar o menu:
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate( R.menu.menu_tela1, menu );
        return true;
    } // fim do onCreateOptionsMenu

    // 4. clique no menu:
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId(); // id do item clicado
        if ( id == R.id.item_avaliar ) {
            // 5. pegar os valroes informados na Tela1:
            String nome = editNome.getText().toString();
            String modalidade = spinModalidade.getSelectedItem().toString();
            boolean maior = swMaioridade.isChecked();
            double bio = rbBio.getRating();
            double gen = rbGen.getRating();
            double psi = rbPsi.getRating();
            // 6. cálculo:
            double media = (5*bio + 3*gen + 2*psi) / 10.0;
            String resultado;
            if ( media > 4 ) {
                resultado = "APTO";
            } else {
                resultado = "NÃO APTO";
            }
            // 7. Intent para levar valores para a Tela2:
            Intent i = new Intent(this, Tela2.class);
            i.putExtra("nome", nome);
            i.putExtra("modalidade", modalidade);
            if ( maior == true ) {
                i.putExtra("maior", "Maior de idade");
            } else {
                i.putExtra("maior", "Menor de idade");
            }
            i.putExtra("media", media);
            i.putExtra("resultado", resultado);
            startActivity( i ); // vai para a Tela2
        } // fim do if
        return super.onOptionsItemSelected(item);
    } // fim do onOptionsItemSelected

} // fim da classe
