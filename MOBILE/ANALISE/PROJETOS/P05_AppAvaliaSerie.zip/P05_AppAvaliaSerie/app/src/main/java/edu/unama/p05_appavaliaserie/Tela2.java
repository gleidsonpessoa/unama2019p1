package edu.unama.p05_appavaliaserie;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class Tela2 extends AppCompatActivity {
    // 1. declaração de variáveis dinâmicas:
    TextView txtTitulo, txtGenero, txtAtiva, txtAvaliacao;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela2);
        // 2. integração entre XML e Java:
        txtTitulo = findViewById(R.id.tela2_titulo);
        txtGenero = findViewById(R.id.tela2_genero);
        txtAtiva  = findViewById(R.id.tela2_ativa);
        txtAvaliacao = findViewById(R.id.tela2_avaliacao);
        // 3. pegar a Intent repassada para cá:
        Intent i = getIntent();
        String titulo = i.getStringExtra("titulo");
        String genero = i.getStringExtra("genero");
        String ativa  = i.getStringExtra("ativa");
        double avaliacao =
                i.getDoubleExtra("avaliacao",0.0);
        // 4. atribuir valores nos TextViews:
        txtTitulo.setText( titulo );
        txtGenero.setText( genero );
        txtAtiva.setText( ativa );
        txtAvaliacao.setText( String.valueOf(avaliacao) );
    } // fim do oncreate

    // 5. associação do menu da Tela2
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate( R.menu.menu_tela2, menu );
        return true;
    } // fim do onCreateOptionsMenu
    // 6. clique no item de menu (compartilhar):

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if ( id == R.id.item_compartilhar ) {
            String s = "Série " + txtTitulo.getText() +
                    " foi avaliada com nota " + txtAvaliacao.getText();
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_SUBJECT, "AvaliaSérie");
            i.putExtra(Intent.EXTRA_TEXT, s);
            startActivity( Intent.createChooser(i,
                    "Compartilhar...") );
        }
        return super.onOptionsItemSelected(item);
    }
} // fim da classe
