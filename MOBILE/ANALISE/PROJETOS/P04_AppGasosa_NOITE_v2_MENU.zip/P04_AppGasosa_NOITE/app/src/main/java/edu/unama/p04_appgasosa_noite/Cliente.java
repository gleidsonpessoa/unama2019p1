package edu.unama.p04_appgasosa_noite;

public class Cliente {
    public static String chave_modelo = "modelo";
    public static String chave_total  = "total";

}
