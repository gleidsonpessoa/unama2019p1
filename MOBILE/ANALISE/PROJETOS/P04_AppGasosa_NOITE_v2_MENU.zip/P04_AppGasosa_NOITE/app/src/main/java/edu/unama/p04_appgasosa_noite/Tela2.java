package edu.unama.p04_appgasosa_noite;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import java.text.DecimalFormat;

public class Tela2 extends AppCompatActivity {
    // 1. componentes dinâmico:
    TextView txtResultado;
    // 2. variáveis para armazenar valores da Tela2:
    String modelo, distancia, potencia, gasolina;
    double total;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela2);
        // 3. pegar a Intent explícita enviada para cá:
        Intent i = getIntent();
        modelo    = i.getStringExtra(Cliente.chave_modelo);
        distancia = i.getStringExtra("distancia");
        potencia  = i.getStringExtra("potencia");
        gasolina  = i.getStringExtra("gasolina");
        total     = i.getDoubleExtra(Cliente.chave_total, 0.0);
        setTitle("RESULTADO");
        // INTEGRAÇÃO ENTRE XML E JAVA:
        txtResultado = findViewById(R.id.txt_resultado);
        // Arredondar total com duas casas decimais
        DecimalFormat df = new DecimalFormat("#.00");
        txtResultado.setText(modelo+" "+potencia+" gasta R$ "+
           df.format(total) +" para percorrer "+distancia+" km com gasolina a R$ "+
           gasolina + " por litro");
    } // fim do onCreate

    public void compartilhar(View v) {

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_tela2, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.item_compartilhar ) {
            // 4. Intent implícita
            Intent c = new Intent( Intent.ACTION_SEND );
            c.setType( "text/plain" );
            c.putExtra( Intent.EXTRA_SUBJECT, "Gasapp" );
            c.putExtra( Intent.EXTRA_TEXT, txtResultado.getText() );
            startActivity( Intent.createChooser(c, "Compartilhar...") );
        }
        return super.onOptionsItemSelected(item);
    }
} // fim da classe
