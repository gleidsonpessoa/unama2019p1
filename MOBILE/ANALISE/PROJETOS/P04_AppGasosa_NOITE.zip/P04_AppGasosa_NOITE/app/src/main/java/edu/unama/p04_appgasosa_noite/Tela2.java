package edu.unama.p04_appgasosa_noite;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Tela2 extends AppCompatActivity {
    // 1. componentes dinâmico:
    TextView txtResultado;
    // 2. variáveis para armazenar valores da Tela2:
    String modelo, distancia, potencia, gasolina;
    double total;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela2);
        // 3. pegar a Intent explícita enviada para cá:
        Intent i = getIntent();
        modelo    = i.getStringExtra("modelo");
        distancia = i.getStringExtra("distancia");
        potencia  = i.getStringExtra("potencia");
        gasolina  = i.getStringExtra("gasolina");
        total     = i.getDoubleExtra("total", 0.0);
        setTitle("RESULTADO");
        txtResultado.setText(modelo+" "+potencia+" gasta R$ "+
           total+" para percorrer "+distancia+" km com gasolina a R$ "+
           gasolina + " por litro");
    } // fim do onCreate

    public void compartilhar(View v) {
        // 4. Intent implícita
        Intent c = new Intent( Intent.ACTION_SEND );
        c.setType( "text/plain" );
        c.putExtra( Intent.EXTRA_SUBJECT, "Gasapp" );
        c.putExtra( Intent.EXTRA_TEXT, txtResultado.getText() );
        startActivity( Intent.createChooser(c, "Compartilhar...") );
    }

} // fim da classe
