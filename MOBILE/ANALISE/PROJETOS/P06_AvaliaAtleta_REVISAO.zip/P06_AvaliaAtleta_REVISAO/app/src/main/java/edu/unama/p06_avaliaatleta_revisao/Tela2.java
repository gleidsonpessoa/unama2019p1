package edu.unama.p06_avaliaatleta_revisao;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class Tela2 extends AppCompatActivity {
    // 1. componentes dinâmicos:
    TextView txtNome, txtModalidade, txtMaior, txtMedia, txtResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela2);
        // 2. integração entre XML e Java:
        txtNome = findViewById(R.id.tela2_nome);
        txtModalidade = findViewById(R.id.tela2_modalidade);
        txtMaior = findViewById(R.id.tela2_maior);
        txtMedia = findViewById(R.id.tela2_nota);
        txtResultado = findViewById(R.id.tela2_resultado);
        // 3. pegar a Intent repassada para cá:
        Intent i = getIntent();
        String nome = i.getStringExtra("nome");
        String modal = i.getStringExtra("modalidade");
        String maior = i.getStringExtra("maior");
        double media = i.getDoubleExtra("media", 0.0);
        String result = i.getStringExtra("resultado");
        // 4. atribuir os valores nos campos dinâmicos:
        txtNome.setText( nome );
        txtModalidade.setText( modal );
        txtMaior.setText( maior );
        txtMedia.setText( "Média geral: " + media );
        txtResultado.setText( result );
    } // fim do onCreate

    // 5. integração do menu da Tela2:
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate( R.menu.menu_tela2, menu );
        return true;
    } // fim do onCreateOptionsMenu
    // 6. clique no menu:
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id == R.id.item_compartilhar) {
            // 7. Intent Implícita:
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_SUBJECT, "AvaliaAtleta");
            i.putExtra(Intent.EXTRA_TEXT, "O atleta " + txtNome.getText()
                + " teve como resultado: " + txtResultado.getText());
            startActivity( Intent.createChooser(i, "Compartilhar...") );
        } //fim do if
        return super.onOptionsItemSelected(item);
    } // fim do onOptionsItemSelected

    // 8. clique no botão:
    public void adicionarFav(View v) {
        Toast.makeText(this,
                "Adicionando aos favoritos...",
                Toast.LENGTH_SHORT).show();
    } // fim do adicionarFav
} // fim da classe
