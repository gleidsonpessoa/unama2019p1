package edu.unama.p06_avaliaatleta_revisao;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.Switch;

public class Tela1 extends AppCompatActivity {
    // 1. componentes dinâmicos:
    EditText editNome;
    Spinner  spinModalidade;
    Switch   swMaior;
    RatingBar rbBio, rbGen, rbPsi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela1);
        // 2. integração entre XML e Java:
        editNome = findViewById(R.id.tela1_nome);
        spinModalidade = findViewById(R.id.tela1_modalidade);
        swMaior = findViewById(R.id.tela1_maior);
        rbBio = findViewById(R.id.tela1_bio);
        rbGen = findViewById(R.id.tela1_gen);
        rbPsi = findViewById(R.id.tela1_psi);
    } // fim do onCreate

    // 3. integração do menu:
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate( R.menu.menu_tela1, menu );
        return true;
    } //  fim do onCreateOptionsMenu

    // 4. clique no item de menu:
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if ( id == R.id.item_avaliar ) {
            // 5. pegar os valores informados na tela:
            String nome = editNome.getText().toString();
            String modalidade = spinModalidade.getSelectedItem().toString();
            boolean maior = swMaior.isChecked();
            double bio = rbBio.getRating();
            double gen = rbGen.getRating();
            double psi = rbPsi.getRating();
            // 6. fazer o cálculo:
            double media = (5*bio + 3*gen + 2*psi) / 10.0;
            // 7. passar os valores para a Tela2:
            Intent i = new Intent(this, Tela2.class);
            i.putExtra("nome", nome);
            i.putExtra("modalidade", modalidade);
            i.putExtra("maior", maior ? "Maior de idade" : "Menor de idade");
            i.putExtra("media", media);
            i.putExtra("resultado", media >= 4 ? "APTO" : "INAPTO");
            startActivity( i );
        } // fim if
        return super.onOptionsItemSelected(item);
    } // fim do onOptionsItemSelected
} // fim da classe
